<div class="left">
						<ul>
							<li><strong>Pinoy Destination</strong></li>
							<li><a href="#">Home</a></li>
							<li><a href="#">Destinations</a></li>
							<li><a href="#">Hotels</a></li>
							<li><a href="#">Restaurants</a></li>
							<li><a href="#">Beaches</a></li>
							<li><a href="#">Resorts</a></li>
							<li><a href="#">Get Listed</a></li>
							<li><a href="#">Plan Your Visit</a></li>
							<li><a href="#">Submit a Review</a></li>
						</ul>
						<ul>
							<li><strong>What to Do</strong></li>
							<li><a href="#">Manila</a></li>
							<li><a href="#">Baguio</a></li>
							<li><a href="#">Cebu</a></li>
							<li><a href="#">Davao</a></li>
							<li><a href="#">Luzon</a></li>
							<li><a href="#">Visayas</a></li>
							<li><a href="#">Mindanao</a></li>
						</ul>
						<ul>
							<li><strong>Where to Stay</strong></li>
							<li><a href="#">Manila</a></li>
							<li><a href="#">Baguio</a></li>
							<li><a href="#">Cebu</a></li>
							<li><a href="#">Davao</a></li>
							<li><a href="#">Luzon</a></li>
							<li><a href="#">Visayas</a></li>
							<li><a href="#">Mindanao</a></li>
						</ul>
						<ul>
							<li><strong>Other Reasons to Visit</strong></li>
							<li><a href="#">Festivals</a></li>
							<li><a href="#">Resorts and Beaches</a></li>
							<li><a href="#">Tourist Attractions</a></li>
							<li><a href="#">The Nightlife</a></li>
							<li><a href="#">Our Food</a></li>
							<li><a href="#">The People</a></li>
						</ul>
						<br clear="all" />
					</div>
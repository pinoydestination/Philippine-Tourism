<span class="myriad_pro_bold_condensed sidebarheader">Side Trips</span>
	<div class="sidetrip">
		<?php for($x=0;$x<=3;$x++){ ?>
		<div class="sidetripcontent">
			<div class="leftcont">
				
			</div>
			<div class="rightcont">
				<div class="sidetriptitle">
					<span class="title">Boracay Island</span>
					<span class="loc">Boracay Island, Aklan</span>
				</div>
				<div>
					<div class="star">
						<div class="star2" style="width:75%;">&nbsp;</div>
					</div>
					<span class="readmoresidetrip"><a href="#" class="sidetriphref">257 reviews</a></span>
					<br clear="all" />
				</div>
			</div>
			<br clear="all" />
		</div>
		<?php } ?>
		<div class="sidefoot">&nbsp;</div>
	</div>
<span class="myriad_pro_bold_condensed sidebarheader">Today's Weather</span>
	<div class="weather">
		<div class="wleft" id="deg"></div>
		<div class="wright">
			<span class="location" id="weatherlocation"></span>
			<span id="weathercondition"></span>
			<span id="sun"></span>
			<i>Powered by Yahoo! Weather</i>
		</div>
		<br clear="all" />
	</div>
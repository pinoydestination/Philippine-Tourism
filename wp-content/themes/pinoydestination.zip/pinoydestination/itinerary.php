<?php
session_start();
?>
<span class="myriad_pro_bold_condensed sidebarheader">My Itinerary</span>
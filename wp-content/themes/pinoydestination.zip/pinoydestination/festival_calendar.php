<span class="myriad_pro_bold_condensed sidebarheader">Philippine Festival</span>
<div class="calendar">
	<div class="calendarbg">
		<span class="month myriad_pro_bold_condensed">October</span>
		<span class="date myriad_pro_bold_condensed">19</span>
	</div>
	<div class="calendardetails">
		<strong class="calendartitle">MassKara Festival</strong>
		Bacolod City
		<div class="desc">
			The MassKara Festival is a festival held each year in Bacolod City, the capital of Negros Occidental province in the Philippines every third weekend of October nearest October 19, the city's Charter Inauguration Anniversary.
		</div>
		<p class="readmore">
			<a href="#">Read More</a>
		</p>
	</div>
	<br clear="all" />
</div>
<div class="sidebarshadow">&nbsp;</div>
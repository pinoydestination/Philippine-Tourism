<?php 
//echo ( $_SERVER['DOCUMENT_ROOT']."/wp-load.php" );
?>
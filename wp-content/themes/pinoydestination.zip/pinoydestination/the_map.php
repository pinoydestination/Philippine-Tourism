<span class="myriad_pro_bold_condensed sidebarheader">The Philippines</span>
<div class="sidebarmap" style="margin-bottom:-2px;">
	<?php /*
	<iframe width="300" height="300" frameborder="0" scrolling="no" marginheight="0" marginwidth="0" src="https://maps.google.com/maps?f=q&amp;source=s_q&amp;hl=en&amp;geocode=+&amp;q=Philippines&amp;ie=UTF8&amp;hq=&amp;hnear=Philippines&amp;t=m&amp;ll=12.897489,121.816406&amp;spn=25.499947,26.279297&amp;z=4&amp;output=embed"></iframe>
	<iframe width="300" height="400" frameborder="0" scrolling="no" marginheight="0" marginwidth="0" src="http://www.pinoydestination.com/gmap.php?address=Philippines&zoom=5"></iframe>
	*/ ?>
	<img class="staticgmap" width="300" height="400" border="0" src="http://www.pinoydestination.com/gstatic.php?address=<?php echo $currentIsland; ?>&zoom=5&size=300x400" />
</div>
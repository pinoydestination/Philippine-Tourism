<span class="myriad_pro_bold_condensed sidebarheader">Pages</span>
<ul class="sidebar_page">
<?php wp_list_pages('title_li='); ?>
</ul>
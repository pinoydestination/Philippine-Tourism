<h1>Sign-up</h1>
<p>
Please fill-up all fields below. All fields are required.
</p>
<form method="post" id="signupform">
<div style="margin-top:10px;">
<input type="text" class="postTitle" id="username" placeholder="Username" name="username" autocomplete="off" />
</div>
<div style="margin-top:10px;">
<input type="password" class="postTitle" id="pass1" placeholder="Password" name="password1" autocomplete="off" /><br />
<input style="margin-top:10px;" type="password" class="postTitle" id="pass2" placeholder="Re-type Password" name="password2" autocomplete="off" /><br />
	<div class="passsss" id="pass-strength-result"></div>
</div>
<div style="margin-top:10px;">
<input type="text" class="postTitle" placeholder="E-Mail Address" name="email" autocomplete="off" />
</div>

<div style="margin-top:10px;">
<input type="submit" value="Submit" />
</div>

</form>
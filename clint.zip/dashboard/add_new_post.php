<input type="text" class="postTitle" placeholder="Post Title" />
<div style="margin-top:10px;">
<input type="text" class="postTitle" placeholder="Address" />
</div>
<div style="margin-top:10px;">
<input type="text" class="postTitle" placeholder="Phone Number" />
</div>
<div style="margin-top:10px;">
<input type="text" class="postTitle" placeholder="E-Mail Address" />
</div>
<div style="margin-top:10px;">
<input type="text" class="postTitle" placeholder="Website" />
</div>
<div style="margin-top:30px;">
	<div>
	<h1>Select Category</h1>
	</div>
</div>
<div style="margin-top:10px;">
	<ul class="categorylist">
		<li><a href="" class="selected">Philippines</a></li>
	</ul>
	<ul class="categorylist">
		<li><a href="">Luzon</a></li>
		<li><a href="" class="selected">Visayas</a></li>
		<li><a href="">Mindanao</a></li>
	</ul>
	<ul class="categorylist">
		<li><a href="">Cebu</a></li>
		<li><a href="">Bohol</a></li>
		<li><a href="" class="selected">Boracay</a></li>
		<li><a href="">Dumaguete</a></li>
		<li><a href="">Ilo-Ilo</a></li>
		<li><a href="">Samar</a></li>
		<li><a href="">Leyte</a></li>
	</ul>
	<ul class="categorylist">
		<li><a href="">Beach</a></li>
		<li><a href="">Resort</a></li>
		<li><a href="" title="The one that has beach and pool">Beach Resort</a></li>
		<li><a href="">Restaurant</a></li>
		<li><a href="" class="selected">Hotel</a></li>
		<li><a href="">Tourist Spot</a></li>
	</ul>
	<br clear="all" />
</div>
<div style="margin-top:30px;">
<h1>Amenities</h1><span>Check all that applies</span>
	<div style="margin-top:10px;">
		<div class="selections">
			<input type="checkbox" name="amenities[]" id="am-1" value="am-1" /> <label for="am-1">Pool</label> <br />
			<input type="checkbox" name="amenities[]" id="am-2" value="am-2" /> <label for="am-2">WiFi Internet</label> <br />
			<input type="checkbox" name="amenities[]" id="am-3" value="am-3" /> <label for="am-3">Restaurant</label> <br />
			<input type="checkbox" name="amenities[]" id="am-4" value="am-4" /> <label for="am-4">Golf Course</label> <br />
			<input type="checkbox" name="amenities[]" id="am-5" value="am-5" /> <label for="am-5">Gym</label> <br />
			<input type="checkbox" name="amenities[]" id="am-6" value="am-6" /> <label for="am-6">Theater</label> <br />
			<input type="checkbox" name="amenities[]" id="am-7" value="am-7" /> <label for="am-7">Biking</label> <br />
		</div>
		<div class="selections">
			
			<input type="checkbox" name="amenities[]" id="am-8" value="am-8" /> <label for="am-8">Billiard</label> <br />
			<input type="checkbox" name="amenities[]" id="am-9" value="am-9" /> <label for="am-9">Beach</label> <br />
			<input type="checkbox" name="amenities[]" id="am-10" value="am-10" /> <label for="am-10">Cable TV</label> <br />
			<input type="checkbox" name="amenities[]" id="am-11" value="am-11" /> <label for="am-11">Bar/Lounge</label> <br />
			<input type="checkbox" name="amenities[]" id="am-12" value="am-12" /> <label for="am-12">Shuttle Service</label> <br />
			<input type="checkbox" name="amenities[]" id="am-13" value="am-13" /> <label for="am-13">Free Breakfast</label> <br />
			<input type="checkbox" name="amenities[]" id="am-14" value="am-14" /> <label for="am-14">Free Parking</label> <br />
		</div>
		<div class="selections">
			
			<input type="checkbox" name="amenities[]" id="am-15" value="am-15" /> <label for="am-15">Room Service</label> <br />
			<input type="checkbox" name="amenities[]" id="am-16" value="am-16" /> <label for="am-16">Free Dinner</label> <br />
			<input type="checkbox" name="amenities[]" id="am-17" value="am-17" /> <label for="am-17">Free Lunch</label> <br />
			<input type="checkbox" name="amenities[]" id="am-18" value="am-18" /> <label for="am-18">Wheelchair Access</label> <br />
			<input type="checkbox" name="amenities[]" id="am-19" value="am-19" /> <label for="am-19">Kids Activities</label> <br />
			<input type="checkbox" name="amenities[]" id="am-20" value="am-20" /> <label for="am-20">Suites</label> <br />
			<input type="checkbox" name="amenities[]" id="am-21" value="am-21" /> <label for="am-21">Shuttle Service</label> <br />
		</div>
		<br clear="all" />
	</div>
</div>
<div style="margin-top:20px;">
<h1>Your Review</h1><br />
<textarea id="textarea2" name="test2" style="width:100%;height:350px;"></textarea>
</div>
$(document).ready(function(){
	$(".haschild").live('mouseover',function(){
		$(this).children("ul.sub").slideDown();
	});
	$(".haschild").live('mouseout',function(){
		$(this).children("ul.sub").slideUp();
	});
	
	
	$('#searchbutton').click(function(){
		if($("#searchframe:visible").length <= 0){
			  
			    $('#searchframe').animate({
			    opacity: 0.9,
			    top: '55'
			  }, 200, function() {
			    // Animation complete.
			    $(this).show();
			  });
			  
		}else{
			$('#searchframe').animate({
			    opacity: 0.0,
			    top: '10'
			  }, 200, function() {
			    // Animation complete.
			    $(this).hide();
			  });
		}
	});
	
	$(".footer .left ul li a").prepend('<span class="arrow">&nbsp;</span>');
	$(".submenu li a").prepend('<span class="arrow">&nbsp;</span>');
	
	
	$(".haschild").hover(function(){
		$(this).find(".submenu").fadeIn();
	},function(){
		$(this).find(".submenu").fadeOut();
	});
	
	$(".footer a, .submenu li a").hover(function(){
		$(this).find("span.arrow").stop().animate({"width":"10px", "margin-right":"2px"},200);
	}, function(){
		$(this).find("span.arrow").stop().animate({"width":"0", "margin-right":"0px"},200);
	});

});
